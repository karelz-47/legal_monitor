# Developer handoff checklist

## Goal

Implement the LegalMonitor REPLIK connector so that user-facing output is clear, localized and stable even if REPLIK returns technical enum codes.

## Deliverables to implement

1. SOAP client for REPLIK.
2. Three UI search modes:
   - IČO
   - Full text
   - Date period
3. Normalization layer using `src/normalizers.ts`.
4. Presentation layer using `src/presenters.ts`.
5. Local code labels using `src/labels.ts` or `i18n/*.json`.
6. Raw source viewer for raw XML + normalized JSON.

## Minimum acceptance criteria

- Searching by IČO returns proceedings and public notices.
- Searching by full text returns proceedings and related notices by case number/court.
- Searching by period returns proceedings and notices for the period.
- UI never displays raw values like `INE_ZVEREJNENIE` as the main label.
- UI preserves raw codes in detail/debug view.
- Unknown future codes render as humanized text and are logged.
- Pagination handles page `0` and up to `100` items per page.

## Suggested user-facing labels

Use Slovak labels by default in LegalMonitor. English labels are included for future multilingual frontend.

## Known limitation

The official public manual does not publish a complete code list for `DruhPodania`. The library therefore includes only `INE_ZVEREJNENIE` plus safe fallback handling. Extend the dictionary as real production values are observed and verified.
