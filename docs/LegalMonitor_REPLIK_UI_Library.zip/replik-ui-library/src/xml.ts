import { XMLParser } from "fast-xml-parser";

export const xmlParser = new XMLParser({
  ignoreAttributes: false,
  removeNSPrefix: true,
  trimValues: true,
  parseTagValue: false,
  parseAttributeValue: false
});

export function parseSoapXml(xml: string): unknown {
  return xmlParser.parse(xml);
}

export function getSoapBody(parsedSoap: unknown): unknown {
  const root = parsedSoap as Record<string, unknown>;
  const envelope = root.Envelope as Record<string, unknown> | undefined;
  if (!envelope) return parsedSoap;
  return envelope.Body ?? parsedSoap;
}

export function unwrapSingleResponse(parsedSoap: unknown): unknown {
  const body = getSoapBody(parsedSoap) as Record<string, unknown>;
  if (!body || typeof body !== "object") return body;
  const keys = Object.keys(body).filter(key => !key.startsWith("#"));
  if (keys.length !== 1) return body;
  return body[keys[0]];
}
