import type {
  Badge,
  DisplayCard,
  FieldValue,
  ReplikLocale,
  ReplikNoticeDetail,
  ReplikNoticeListItem,
  ReplikProceedingDetail,
  ReplikProceedingListItem,
  SearchSummary,
  Severity
} from "./types";
import { getCodeLabel, getSeverityForCodes } from "./labels";
import { compactText, formatDate, maxSeverity } from "./utils";

const FIELD_LABELS: Record<ReplikLocale, Record<string, string>> = {
  sk: {
    caseNumber: "Spisová značka",
    debtor: "Dlžník",
    debtorIco: "IČO dlžníka",
    court: "Súd",
    administrator: "Správca",
    status: "Stav konania",
    startDate: "Začatie konania",
    processStartDate: "Začatie procesu",
    filingDate: "Dátum podania",
    lastEventDate: "Posledná udalosť",
    noticeType: "Typ oznamu",
    proceedingType: "Typ konania",
    publishedDate: "Dátum zverejnenia",
    filingType: "Druh podania",
    textKind: "Druh textu",
    hasAttachments: "Prílohy"
  },
  en: {
    caseNumber: "Case number",
    debtor: "Debtor",
    debtorIco: "Debtor ID No.",
    court: "Court",
    administrator: "Administrator",
    status: "Proceeding status",
    startDate: "Proceeding start",
    processStartDate: "Process start",
    filingDate: "Filing date",
    lastEventDate: "Last event",
    noticeType: "Notice type",
    proceedingType: "Proceeding type",
    publishedDate: "Publication date",
    filingType: "Filing type",
    textKind: "Text type",
    hasAttachments: "Attachments"
  }
};

function fv(locale: ReplikLocale, key: string, value: string | null, important = false, rawValue?: unknown): FieldValue {
  return { key, label: FIELD_LABELS[locale][key] ?? key, value, important, rawValue };
}

function badge(label: string, tone: Severity, rawCode?: string | null, tooltip?: string): Badge {
  return { label, tone, rawCode: rawCode ?? undefined, tooltip };
}

export function proceedingToCard(item: ReplikProceedingListItem | ReplikProceedingDetail, locale: ReplikLocale = "sk"): DisplayCard {
  const type = getCodeLabel("konanieTyp", item.proceedingTypeCode, locale);
  const status = getCodeLabel("stavKonania", item.statusCode, locale);
  const severity = getSeverityForCodes([
    { group: "konanieTyp", code: item.proceedingTypeCode },
    { group: "stavKonania", code: item.statusCode }
  ], locale);

  const title = type.label;
  const debtor = [item.debtorName, item.debtorIco ? `IČO ${item.debtorIco}` : null].filter(Boolean).join(" · ");
  const court = [item.courtName, item.caseNumber].filter(Boolean).join(" · ");
  const subtitle = [debtor, court].filter(Boolean).join("\n");

  return {
    id: item.id ?? `${item.caseNumber ?? "unknown"}-${item.courtCode ?? "court"}`,
    type: "proceeding",
    title,
    subtitle,
    date: formatDate(item.lastEventDate ?? item.startDate, locale === "sk" ? "sk-SK" : "en-GB"),
    severity,
    badges: [
      badge(type.label, type.severity, item.proceedingTypeCode, type.description),
      item.statusCode ? badge(status.label, status.severity, item.statusCode, status.description) : null
    ].filter(Boolean) as Badge[],
    fields: [
      fv(locale, "debtor", item.debtorName, true),
      fv(locale, "debtorIco", item.debtorIco, true),
      fv(locale, "caseNumber", item.caseNumber, true),
      fv(locale, "court", item.courtName, true, item.courtCode),
      fv(locale, "administrator", item.administratorName, false),
      fv(locale, "status", item.statusCode ? status.label : null, false, item.statusCode),
      fv(locale, "startDate", formatDate(item.startDate, locale === "sk" ? "sk-SK" : "en-GB"), false, item.startDate),
      fv(locale, "processStartDate", formatDate(item.processStartDate, locale === "sk" ? "sk-SK" : "en-GB"), false, item.processStartDate),
      fv(locale, "filingDate", formatDate(item.filingDate, locale === "sk" ? "sk-SK" : "en-GB"), false, item.filingDate),
      fv(locale, "lastEventDate", formatDate(item.lastEventDate, locale === "sk" ? "sk-SK" : "en-GB"), false, item.lastEventDate)
    ].filter(field => field.value !== null),
    raw: item.raw ?? item
  };
}

export function noticeToCard(item: ReplikNoticeListItem | ReplikNoticeDetail, locale: ReplikLocale = "sk"): DisplayCard {
  const noticeType = getCodeLabel("oznamTyp", item.noticeTypeCode, locale);
  const proceedingType = getCodeLabel("konanieTyp", item.proceedingTypeCode, locale);
  const detail = item as ReplikNoticeDetail;
  const filingType = getCodeLabel("druhPodania", detail.filingTypeCode, locale);
  const textKind = getCodeLabel("textDruh", detail.textKindCode, locale);

  const severity = maxSeverity([noticeType.severity, proceedingType.severity, filingType.severity, textKind.severity]);
  const title = `${noticeType.label}${proceedingType.label ? ` · ${proceedingType.label}` : ""}`;
  const subtitle = [item.courtName, item.courtCaseNumber].filter(Boolean).join(" · ");

  return {
    id: item.noticeId ?? `${item.courtCaseNumber ?? "unknown"}-${item.publishedDate ?? "date"}`,
    type: "notice",
    title,
    subtitle,
    date: formatDate(item.publishedDate, locale === "sk" ? "sk-SK" : "en-GB"),
    severity,
    badges: [
      badge(noticeType.label, noticeType.severity, item.noticeTypeCode, noticeType.description),
      badge(proceedingType.label, proceedingType.severity, item.proceedingTypeCode, proceedingType.description),
      detail.filingTypeCode ? badge(filingType.label, filingType.severity, detail.filingTypeCode, filingType.description) : null,
      detail.textKindCode ? badge(textKind.label, textKind.severity, detail.textKindCode, textKind.description) : null
    ].filter(Boolean) as Badge[],
    fields: [
      fv(locale, "publishedDate", formatDate(item.publishedDate, locale === "sk" ? "sk-SK" : "en-GB"), true, item.publishedDate),
      fv(locale, "noticeType", noticeType.label, true, item.noticeTypeCode),
      fv(locale, "proceedingType", proceedingType.label, true, item.proceedingTypeCode),
      fv(locale, "caseNumber", item.courtCaseNumber, true),
      fv(locale, "court", item.courtName, true, item.courtCode),
      fv(locale, "filingType", detail.filingTypeCode ? filingType.label : null, false, detail.filingTypeCode),
      fv(locale, "textKind", detail.textKindCode ? textKind.label : null, false, detail.textKindCode),
      fv(locale, "hasAttachments", typeof detail.hasAttachments === "boolean" ? (detail.hasAttachments ? (locale === "sk" ? "Áno" : "Yes") : (locale === "sk" ? "Nie" : "No")) : null, false, detail.hasAttachments)
    ].filter(field => field.value !== null),
    body: compactText([
      detail.headerText,
      detail.decisionText,
      detail.noticeText,
      detail.administratorText,
      detail.reasoningText,
      detail.instructionText
    ]),
    raw: item.raw ?? item
  };
}

export function buildSearchSummary(args: {
  searchMode: SearchSummary["searchMode"];
  query: SearchSummary["query"];
  proceedings: Array<ReplikProceedingListItem | ReplikProceedingDetail>;
  notices: Array<ReplikNoticeListItem | ReplikNoticeDetail>;
  locale?: ReplikLocale;
}): SearchSummary {
  const locale = args.locale ?? "sk";
  const proceedingSeverities = args.proceedings.map(p => proceedingToCard(p, locale).severity);
  const noticeSeverities = args.notices.map(n => noticeToCard(n, locale).severity);
  const highestSeverity = maxSeverity([...proceedingSeverities, ...noticeSeverities]);

  const proceedingsCount = args.proceedings.length;
  const noticesCount = args.notices.length;

  const headline = locale === "sk"
    ? (proceedingsCount || noticesCount ? "REPLIK obsahuje relevantné záznamy." : "REPLIK nevrátil relevantné záznamy.")
    : (proceedingsCount || noticesCount ? "REPLIK returned relevant records." : "REPLIK returned no relevant records.");

  const explanation = locale === "sk"
    ? `Nájdené konania: ${proceedingsCount}. Nájdené verejné oznamy: ${noticesCount}.`
    : `Proceedings found: ${proceedingsCount}. Public notices found: ${noticesCount}.`;

  return {
    source: "REPLIK",
    searchMode: args.searchMode,
    query: args.query,
    queriedAt: new Date().toISOString(),
    proceedingsCount,
    noticesCount,
    highestSeverity,
    headline,
    explanation
  };
}
