import type {
  ReplikNoticeDetail,
  ReplikNoticeListItem,
  ReplikProceedingDetail,
  ReplikProceedingListItem,
  ReplikPersonOrEntity,
  ReplikAddress
} from "./types";
import { coalesceString, toBoolean } from "./utils";

export type AnyRecord = Record<string, unknown>;

function get(obj: AnyRecord | null | undefined, ...keys: string[]): unknown {
  if (!obj) return undefined;
  for (const key of keys) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) return obj[key];
  }
  return undefined;
}

function str(obj: AnyRecord | null | undefined, ...keys: string[]): string | null {
  return coalesceString(...keys.map(key => get(obj, key)));
}

export function normalizeAddress(input?: AnyRecord | null): ReplikAddress | null {
  if (!input) return null;
  return {
    street: str(input, "Ulica", "ulica", "street"),
    streetNumber: str(input, "Cislo", "cislo", "streetNumber"),
    municipality: str(input, "Obec", "obec", "municipality"),
    postalCode: str(input, "Psc", "PSC", "psc", "postalCode"),
    country: str(input, "Krajina", "krajina", "country")
  };
}

export function normalizePersonOrEntity(input?: AnyRecord | null): ReplikPersonOrEntity | null {
  if (!input) return null;
  const addressObject = get(input, "Adresa", "adresa", "address") as AnyRecord | undefined;
  return {
    name: str(input, "Meno", "Nazov", "ObchodneMeno", "name", "corporateName"),
    ico: str(input, "Ico", "ICO", "ico", "cin"),
    birthDate: str(input, "DatumNarodenia", "birthDate"),
    registryMark: str(input, "Znacka", "SpravcovskaZnacka", "registryMark"),
    address: normalizeAddress(addressObject)
  };
}

export function normalizeProceedingListItem(input: AnyRecord): ReplikProceedingListItem {
  return {
    id: str(input, "Id", "KonanieId", "id"),
    caseNumber: str(input, "SpisovaZnackaSudu", "spisovaZnackaSudu", "caseNumber"),
    proceedingTypeCode: str(input, "Typ", "KonanieTyp", "typ", "konanieTyp", "proceedingTypeCode"),
    startDate: str(input, "DatumZacatiaKonania", "DatumZacatiaKonanie", "startDate"),
    processStartDate: str(input, "DatumZacatiaProcesu", "processStartDate"),
    filingDate: str(input, "DatumPodania", "filingDate"),
    debtorName: str(input, "Dlznik", "DlznikMeno", "debtorName"),
    debtorIco: str(input, "DlznikIco", "Ico", "debtorIco"),
    lastEventDate: str(input, "DatumPoslednejUdalosti", "lastEventDate"),
    courtCode: str(input, "Sud", "SudKod", "courtCode"),
    courtName: str(input, "SudNazov", "courtName"),
    administratorName: str(input, "Spravca", "administratorName"),
    statusCode: str(input, "StavKonania", "statusCode"),
    raw: input
  };
}

export function normalizeProceedingDetail(input: AnyRecord): ReplikProceedingDetail {
  const base = normalizeProceedingListItem(input);
  const debtorObject = get(input, "Dlznik", "dlznik", "debtor") as AnyRecord | undefined;
  const administratorObject = get(input, "Spravca", "spravca", "administrator") as AnyRecord | undefined;
  const applicantsValue = get(input, "Navrhovatel", "Navrhovatelia", "applicants");
  const applicants = Array.isArray(applicantsValue) ? applicantsValue : applicantsValue ? [applicantsValue] : [];

  return {
    ...base,
    debtor: normalizePersonOrEntity(debtorObject) ?? (base.debtorName || base.debtorIco ? { name: base.debtorName, ico: base.debtorIco } : null),
    applicants: applicants.map(item => normalizePersonOrEntity(item as AnyRecord)).filter(Boolean) as ReplikPersonOrEntity[],
    judgeName: str(input, "Sudca", "judgeName"),
    administrator: normalizePersonOrEntity(administratorObject) ?? (base.administratorName ? { name: base.administratorName } : null),
    administratorTypeCode: str(input, "TypSpravcu", "administratorTypeCode")
  };
}

export function normalizeNoticeListItem(input: AnyRecord): ReplikNoticeListItem {
  return {
    noticeId: str(input, "OznamId", "noticeId"),
    noticeTypeCode: str(input, "OznamTyp", "noticeTypeCode"),
    courtCode: str(input, "SudKod", "courtCode"),
    courtName: str(input, "SudNazov", "courtName"),
    courtCaseNumber: str(input, "SpisovaZnackaSudnehoSpisu", "courtCaseNumber"),
    proceedingId: str(input, "KonanieId", "proceedingId"),
    proceedingTypeCode: str(input, "KonanieTyp", "proceedingTypeCode"),
    publishedDate: str(input, "DatumVydania", "publishedDate"),
    raw: input
  };
}

export function normalizeNoticeDetail(input: AnyRecord): ReplikNoticeDetail {
  const base = normalizeNoticeListItem(input);
  return {
    ...base,
    hasAttachments: toBoolean(get(input, "ObsahujePrilohy", "hasAttachments")),
    textKindCode: str(input, "TextDruh", "textKindCode"),
    filingTypeCode: str(input, "DruhPodania", "filingTypeCode"),
    instructionText: str(input, "TextPoucenie", "instructionText"),
    headerText: str(input, "TextHlavicka", "headerText"),
    reasoningText: str(input, "TextOdovodnenie", "reasoningText"),
    noticeText: str(input, "TextOznam", "noticeText"),
    decisionText: str(input, "TextRozhodnutie", "decisionText"),
    administratorText: str(input, "Text", "administratorText"),
    administratorCaseNumber: str(input, "SpisovaZnackaSpravcovskehoSpisu", "administratorCaseNumber")
  };
}
