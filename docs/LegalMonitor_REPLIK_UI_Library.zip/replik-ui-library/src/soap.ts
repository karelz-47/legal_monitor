export type ReplikEnvironment = "production" | "test";
export type ReplikSorting = "DatumPoslednejUdalosti" | "DatumZacatiaKonania" | "Relevancia";

export const REPLIK_ENDPOINTS = {
  production: {
    serviceBase: "https://replik-ws.justice.sk/ru-verejnost-ws/",
    konanieWsdl: "https://replik-ws.justice.sk/ru-verejnost-ws/konanieService.wsdl",
    oznamWsdl: "https://replik-ws.justice.sk/ru-verejnost-ws/oznamService.wsdl"
  },
  test: {
    serviceBase: "https://replik-wst.justice.sk/ru-verejnost-ws/",
    konanieWsdl: "https://replik-wst.justice.sk/ru-verejnost-ws/konanieService.wsdl",
    oznamWsdl: "https://replik-wst.justice.sk/ru-verejnost-ws/oznamService.wsdl"
  }
} as const;

const KONANIE_NS = "datatypes.konanie.verejnost.ru.sk.hp.com";
const OZNAM_NS = "datatypes.oznam.verejnost.ru.sk.hp.com";

function esc(value: string | number): string {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function envelope(namespace: string, body: string): string {
  return `<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dat="${namespace}">
  <soapenv:Header/>
  <soapenv:Body>
${body}
  </soapenv:Body>
</soapenv:Envelope>`;
}

export function buildGetKonaniePodlaIcoRequest(args: { ico: string; page?: number; pageSize?: number; sorting?: ReplikSorting }): string {
  return envelope(KONANIE_NS, `    <dat:getKonaniePodlaICORequest>
      <dat:Ico>${esc(args.ico)}</dat:Ico>
      <dat:Stranka>${args.page ?? 0}</dat:Stranka>
      <dat:VysledkovNaStranku>${args.pageSize ?? 100}</dat:VysledkovNaStranku>
      <dat:TypTriedenia>${args.sorting ?? "DatumPoslednejUdalosti"}</dat:TypTriedenia>
    </dat:getKonaniePodlaICORequest>`);
}

export function buildVyhladajKonanieRequest(args: { query: string; page?: number; pageSize?: number; sorting?: ReplikSorting }): string {
  return envelope(KONANIE_NS, `    <dat:vyhladajKonanieRequest>
      <dat:Query>${esc(args.query)}</dat:Query>
      <dat:Stranka>${args.page ?? 0}</dat:Stranka>
      <dat:VysledkovNaStranku>${args.pageSize ?? 100}</dat:VysledkovNaStranku>
      <dat:TypTriedenia>${args.sorting ?? "Relevancia"}</dat:TypTriedenia>
    </dat:vyhladajKonanieRequest>`);
}

export function buildGetKonaniePreObdobieRequest(args: { dateFrom: string; dateTo: string; page?: number; pageSize?: number }): string {
  return envelope(KONANIE_NS, `    <dat:getKonaniePreObdobieRequest>
      <dat:DatumOd>${esc(args.dateFrom)}</dat:DatumOd>
      <dat:DatumDo>${esc(args.dateTo)}</dat:DatumDo>
      <dat:Stranka>${args.page ?? 0}</dat:Stranka>
      <dat:VysledkovNaStranku>${args.pageSize ?? 100}</dat:VysledkovNaStranku>
    </dat:getKonaniePreObdobieRequest>`);
}

export function buildGetKonanieDetailRequest(konanieId: string): string {
  return envelope(KONANIE_NS, `    <dat:getKonanieDetailRequest>
      <dat:KonanieId>${esc(konanieId)}</dat:KonanieId>
    </dat:getKonanieDetailRequest>`);
}

export function buildGetKonanieDetailPodlaZnackyASuduRequest(args: { caseNumber: string; courtCode: string }): string {
  return envelope(KONANIE_NS, `    <dat:getKonanieDetailPodlaZnackyASuduRequest>
      <dat:KonanieZnacka>${esc(args.caseNumber)}</dat:KonanieZnacka>
      <dat:KonanieSud>${esc(args.courtCode)}</dat:KonanieSud>
    </dat:getKonanieDetailPodlaZnackyASuduRequest>`);
}

export function buildVyhladajPoslednuZmenuOdRequest(args: { changedSinceIso: string; limit?: number }): string {
  return envelope(KONANIE_NS, `    <dat:vyhladajPoslednuZmenuOdRequest>
      <dat:DatumOd>${esc(args.changedSinceIso)}</dat:DatumOd>
      <dat:Vysledkov>${args.limit ?? 100}</dat:Vysledkov>
    </dat:vyhladajPoslednuZmenuOdRequest>`);
}

export function buildGetZoznamSudovRequest(): string {
  return envelope(KONANIE_NS, `    <dat:getZoznamSudovRequest/>`);
}

export function buildGetVerejneOznamyPodlaIcoRequest(args: { ico: string; page?: number; pageSize?: number }): string {
  return envelope(OZNAM_NS, `    <dat:getVerejneOznamyPodlaICORequest>
      <dat:Ico>${esc(args.ico)}</dat:Ico>
      <dat:Stranka>${args.page ?? 0}</dat:Stranka>
      <dat:VysledkovNaStranku>${args.pageSize ?? 100}</dat:VysledkovNaStranku>
    </dat:getVerejneOznamyPodlaICORequest>`);
}

export function buildGetVerejneOznamyPreObdobieRequest(args: { dateFrom: string; dateTo: string; page?: number; pageSize?: number }): string {
  return envelope(OZNAM_NS, `    <dat:getVerejneOznamyPreObdobieRequest>
      <dat:DatumOd>${esc(args.dateFrom)}</dat:DatumOd>
      <dat:DatumDo>${esc(args.dateTo)}</dat:DatumDo>
      <dat:Stranka>${args.page ?? 0}</dat:Stranka>
      <dat:VysledkovNaStranku>${args.pageSize ?? 100}</dat:VysledkovNaStranku>
    </dat:getVerejneOznamyPreObdobieRequest>`);
}

export function buildGetVerejnyOznamPodlaZnackyASuduRequest(args: { caseNumber: string; courtCode: string; page?: number; pageSize?: number }): string {
  return envelope(OZNAM_NS, `    <dat:getVerejnyOznamPodlaZnackyASuduRequest>
      <dat:SpisovaZnackaSudnehoSpisu>${esc(args.caseNumber)}</dat:SpisovaZnackaSudnehoSpisu>
      <dat:SudKod>${esc(args.courtCode)}</dat:SudKod>
      <dat:Stranka>${args.page ?? 0}</dat:Stranka>
      <dat:VysledkovNaStranku>${args.pageSize ?? 100}</dat:VysledkovNaStranku>
    </dat:getVerejnyOznamPodlaZnackyASuduRequest>`);
}

export function buildGetVerejnyOznamDetailRequest(oznamId: string): string {
  return envelope(OZNAM_NS, `    <dat:getVerejnyOznamDetailRequest>
      <dat:OznamId>${esc(oznamId)}</dat:OznamId>
    </dat:getVerejnyOznamDetailRequest>`);
}
