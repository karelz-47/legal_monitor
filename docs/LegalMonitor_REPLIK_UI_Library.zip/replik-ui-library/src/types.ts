export type ReplikLocale = "sk" | "en";

export type Severity = "neutral" | "info" | "warning" | "critical";

export type ReplikCodeGroup =
  | "konanieTyp"
  | "oznamTyp"
  | "druhPodania"
  | "stavKonania"
  | "typSpravcu"
  | "textDruh"
  | "typTriedenia";

export interface CodeLabel {
  code: string;
  label: string;
  description: string;
  severity: Severity;
}

export interface FieldValue {
  key: string;
  label: string;
  value: string | null;
  rawValue?: unknown;
  important?: boolean;
}

export interface Badge {
  label: string;
  tone: Severity;
  rawCode?: string;
  tooltip?: string;
}

export interface ReplikProceedingListItem {
  id: string | null;
  caseNumber: string | null;
  proceedingTypeCode: string | null;
  startDate: string | null;
  processStartDate: string | null;
  filingDate: string | null;
  debtorName: string | null;
  debtorIco: string | null;
  lastEventDate: string | null;
  courtCode: string | null;
  courtName: string | null;
  administratorName: string | null;
  statusCode: string | null;
  raw?: unknown;
}

export interface ReplikProceedingDetail extends ReplikProceedingListItem {
  applicants?: ReplikPersonOrEntity[];
  debtor?: ReplikPersonOrEntity | null;
  judgeName?: string | null;
  administrator?: ReplikPersonOrEntity | null;
  administratorTypeCode?: string | null;
}

export interface ReplikPersonOrEntity {
  name: string | null;
  ico?: string | null;
  birthDate?: string | null;
  address?: ReplikAddress | null;
  registryMark?: string | null;
}

export interface ReplikAddress {
  street?: string | null;
  streetNumber?: string | null;
  municipality?: string | null;
  postalCode?: string | null;
  country?: string | null;
}

export interface ReplikNoticeListItem {
  noticeId: string | null;
  noticeTypeCode: string | null;
  courtCode: string | null;
  courtName: string | null;
  courtCaseNumber: string | null;
  proceedingId: string | null;
  proceedingTypeCode: string | null;
  publishedDate: string | null;
  raw?: unknown;
}

export interface ReplikNoticeDetail extends ReplikNoticeListItem {
  hasAttachments?: boolean | null;
  textKindCode?: string | null;
  filingTypeCode?: string | null;
  instructionText?: string | null;
  headerText?: string | null;
  reasoningText?: string | null;
  noticeText?: string | null;
  decisionText?: string | null;
  administratorText?: string | null;
  administratorCaseNumber?: string | null;
}

export interface DisplayCard {
  id: string;
  type: "proceeding" | "notice";
  title: string;
  subtitle: string;
  date: string | null;
  severity: Severity;
  badges: Badge[];
  fields: FieldValue[];
  body?: string | null;
  raw?: unknown;
}

export interface SearchSummary {
  source: "REPLIK";
  searchMode: "ico" | "fulltext" | "period" | "caseAndCourt";
  query: Record<string, string | number | null>;
  queriedAt: string;
  proceedingsCount: number;
  noticesCount: number;
  highestSeverity: Severity;
  headline: string;
  explanation: string;
}
