import type { CodeLabel, ReplikCodeGroup, ReplikLocale, Severity } from "./types";
import { humanizeCode, normalizeCode } from "./utils";

const SK: Record<ReplikCodeGroup, Record<string, CodeLabel>> = {
  konanieTyp: {
    KONKURZ: {
      code: "KONKURZ",
      label: "Konkurz",
      description: "Insolvenčné konanie týkajúce sa majetku dlžníka.",
      severity: "critical"
    },
    MALYKONKURZ: {
      code: "MALYKONKURZ",
      label: "Malý konkurz",
      description: "Zjednodušený konkurzný režim pre menšie prípady.",
      severity: "critical"
    },
    RESTRUKTURALIZACIA: {
      code: "RESTRUKTURALIZACIA",
      label: "Reštrukturalizácia",
      description: "Súdne vedený proces ozdravenia dlžníka podľa reštrukturalizačného plánu.",
      severity: "warning"
    },
    INEKONANIA: {
      code: "INEKONANIA",
      label: "Iné konanie",
      description: "Iný typ konania evidovaný v REPLIK mimo hlavné štandardné kategórie.",
      severity: "info"
    },
    ODDLZENIE_KONKURZ: {
      code: "ODDLZENIE_KONKURZ",
      label: "Oddlženie – konkurz",
      description: "Osobné oddlženie formou konkurzu.",
      severity: "warning"
    },
    ODDLZENIE_SPLATKOVY_KALENDAR: {
      code: "ODDLZENIE_SPLATKOVY_KALENDAR",
      label: "Oddlženie – splátkový kalendár",
      description: "Osobné oddlženie formou splátkového kalendára.",
      severity: "warning"
    },
    LIKVIDACIA: {
      code: "LIKVIDACIA",
      label: "Likvidácia",
      description: "Likvidačné konanie alebo súvisiaci proces pri zrušovaní právnickej osoby.",
      severity: "warning"
    },
    VPR: {
      code: "VPR",
      label: "Verejná preventívna reštrukturalizácia",
      description: "Preventívna reštrukturalizácia pred plnou insolvenčnou situáciou.",
      severity: "warning"
    }
  },
  oznamTyp: {
    OZNAM_SUD: {
      code: "OZNAM_SUD",
      label: "Oznam súdu",
      description: "Oznam alebo rozhodnutie zverejnené súdom.",
      severity: "info"
    },
    OZNAM_SPRAVCA: {
      code: "OZNAM_SPRAVCA",
      label: "Oznam správcu",
      description: "Oznam zverejnený správcom, likvidátorom alebo inou osobou v príslušnej procesnej role.",
      severity: "info"
    }
  },
  druhPodania: {
    INE_ZVEREJNENIE: {
      code: "INE_ZVEREJNENIE",
      label: "Iné zverejnenie",
      description: "Všeobecný typ zverejnenia bez špecifickejšieho verejne dokumentovaného zaradenia.",
      severity: "info"
    }
  },
  stavKonania: {
    SKONCENY_PROCES: {
      code: "SKONCENY_PROCES",
      label: "Skončený proces",
      description: "Proces je v REPLIK vedený ako skončený.",
      severity: "neutral"
    },
    ZASTAVENE_KONANIE: {
      code: "ZASTAVENE_KONANIE",
      label: "Zastavené konanie",
      description: "Konanie je vedené ako zastavené.",
      severity: "neutral"
    },
    PREBIEHAJUCE_KONANIE: {
      code: "PREBIEHAJUCE_KONANIE",
      label: "Prebiehajúce konanie",
      description: "Konanie je vedené ako prebiehajúce.",
      severity: "warning"
    }
  },
  typSpravcu: {
    RIADNY: {
      code: "RIADNY",
      label: "Riadny správca",
      description: "Riadny správca priradený ku konaniu.",
      severity: "info"
    },
    PREDBEZNY: {
      code: "PREDBEZNY",
      label: "Predbežný správca",
      description: "Predbežný správca priradený ku konaniu.",
      severity: "info"
    }
  },
  textDruh: {
    UZNESENIE: {
      code: "UZNESENIE",
      label: "Uznesenie",
      description: "Súdne rozhodnutie vo forme uznesenia.",
      severity: "info"
    }
  },
  typTriedenia: {
    DATUMPOSLEDNEJUDALOSTI: {
      code: "DatumPoslednejUdalosti",
      label: "Dátum poslednej udalosti",
      description: "Výsledky sú zoradené podľa dátumu poslednej operácie vykonanej na konaní.",
      severity: "neutral"
    },
    DATUMZACATIAKONANIA: {
      code: "DatumZacatiaKonania",
      label: "Dátum začatia konania",
      description: "Výsledky sú zoradené podľa dátumu začatia konania.",
      severity: "neutral"
    },
    RELEVANCIA: {
      code: "Relevancia",
      label: "Relevancia",
      description: "Výsledky sú zoradené podľa relevancie vyhľadávaného výrazu.",
      severity: "neutral"
    }
  }
};

const EN: Record<ReplikCodeGroup, Record<string, CodeLabel>> = {
  konanieTyp: {
    KONKURZ: { code: "KONKURZ", label: "Bankruptcy", description: "Insolvency proceeding concerning the debtor's assets.", severity: "critical" },
    MALYKONKURZ: { code: "MALYKONKURZ", label: "Small bankruptcy", description: "Simplified bankruptcy regime for smaller cases.", severity: "critical" },
    RESTRUKTURALIZACIA: { code: "RESTRUKTURALIZACIA", label: "Restructuring", description: "Court-supervised debtor restructuring process.", severity: "warning" },
    INEKONANIA: { code: "INEKONANIA", label: "Other proceeding", description: "Other REPLIK proceeding type outside the main standard categories.", severity: "info" },
    ODDLZENIE_KONKURZ: { code: "ODDLZENIE_KONKURZ", label: "Debt relief – bankruptcy", description: "Personal debt relief through bankruptcy.", severity: "warning" },
    ODDLZENIE_SPLATKOVY_KALENDAR: { code: "ODDLZENIE_SPLATKOVY_KALENDAR", label: "Debt relief – repayment schedule", description: "Personal debt relief through repayment schedule.", severity: "warning" },
    LIKVIDACIA: { code: "LIKVIDACIA", label: "Liquidation", description: "Liquidation proceeding or related process for winding up a legal entity.", severity: "warning" },
    VPR: { code: "VPR", label: "Public preventive restructuring", description: "Preventive restructuring before full insolvency.", severity: "warning" }
  },
  oznamTyp: {
    OZNAM_SUD: { code: "OZNAM_SUD", label: "Court notice", description: "Notice or decision published by the court.", severity: "info" },
    OZNAM_SPRAVCA: { code: "OZNAM_SPRAVCA", label: "Administrator notice", description: "Notice published by the administrator, liquidator or person acting in the relevant procedural role.", severity: "info" }
  },
  druhPodania: {
    INE_ZVEREJNENIE: { code: "INE_ZVEREJNENIE", label: "Other publication", description: "Generic publication type without a more specific publicly documented category.", severity: "info" }
  },
  stavKonania: {
    SKONCENY_PROCES: { code: "SKONCENY_PROCES", label: "Completed process", description: "The process is recorded as completed in REPLIK.", severity: "neutral" },
    ZASTAVENE_KONANIE: { code: "ZASTAVENE_KONANIE", label: "Stopped proceeding", description: "The proceeding is recorded as stopped.", severity: "neutral" },
    PREBIEHAJUCE_KONANIE: { code: "PREBIEHAJUCE_KONANIE", label: "Ongoing proceeding", description: "The proceeding is recorded as ongoing.", severity: "warning" }
  },
  typSpravcu: {
    RIADNY: { code: "RIADNY", label: "Regular administrator", description: "Regular administrator assigned to the proceeding.", severity: "info" },
    PREDBEZNY: { code: "PREDBEZNY", label: "Interim administrator", description: "Interim administrator assigned to the proceeding.", severity: "info" }
  },
  textDruh: {
    UZNESENIE: { code: "UZNESENIE", label: "Court resolution", description: "Court decision in the form of a resolution/order.", severity: "info" }
  },
  typTriedenia: {
    DATUMPOSLEDNEJUDALOSTI: { code: "DatumPoslednejUdalosti", label: "Date of last event", description: "Results sorted by the last operation performed on the proceeding.", severity: "neutral" },
    DATUMZACATIAKONANIA: { code: "DatumZacatiaKonania", label: "Proceeding start date", description: "Results sorted by proceeding start date.", severity: "neutral" },
    RELEVANCIA: { code: "Relevancia", label: "Relevance", description: "Results sorted by relevance of the search expression.", severity: "neutral" }
  }
};

const DICTS = { sk: SK, en: EN } as const;

export function getCodeLabel(group: ReplikCodeGroup, code?: string | null, locale: ReplikLocale = "sk"): CodeLabel {
  const normalized = normalizeCode(code);
  const direct = DICTS[locale][group][normalized];
  if (direct) return direct;

  // Sorting values in REPLIK use mixed case and no separators; normalizeCode may preserve enough but this fallback helps.
  const compact = normalized.replace(/_/g, "");
  const byCompact = Object.values(DICTS[locale][group]).find(item => normalizeCode(item.code).replace(/_/g, "") === compact);
  if (byCompact) return byCompact;

  const label = locale === "sk" ? humanizeCode(code) : humanizeCode(code);
  const missingDescription = locale === "sk"
    ? "Neznámy alebo nový kód z REPLIK. Pôvodnú hodnotu ponechajte v detaile záznamu a doplňte mapovanie po overení."
    : "Unknown or new REPLIK code. Keep the original value in the record detail and add mapping after verification.";

  return {
    code: code ?? "",
    label,
    description: missingDescription,
    severity: "info"
  };
}

export function getSeverityForCodes(codes: Array<{ group: ReplikCodeGroup; code?: string | null }>, locale: ReplikLocale = "sk"): Severity {
  const rank: Record<Severity, number> = { neutral: 0, info: 1, warning: 2, critical: 3 };
  return codes
    .map(item => getCodeLabel(item.group, item.code, locale).severity)
    .reduce((max, current) => (rank[current] > rank[max] ? current : max), "neutral" as Severity);
}
