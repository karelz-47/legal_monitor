import type { Severity } from "./types";

export function normalizeCode(code?: string | null): string {
  if (!code) return "";
  const normalized = code
    .trim()
    .replace(/[\s-]+/g, "_")
    .replace(/_+/g, "_")
    .toUpperCase();

  // REPLIK examples/manual are not fully consistent between hyphen and underscore variants.
  if (normalized === "ODDLZENIE_SPLATKOVYKALENDAR") return "ODDLZENIE_SPLATKOVY_KALENDAR";
  return normalized;
}

export function humanizeCode(code?: string | null): string {
  if (!code) return "Neuvedené";
  return code
    .replace(/[\s_-]+/g, " ")
    .trim()
    .toLocaleLowerCase("sk-SK")
    .replace(/(^|\s)\p{L}/gu, part => part.toLocaleUpperCase("sk-SK"));
}

export function coalesceString(...values: Array<unknown>): string | null {
  for (const value of values) {
    if (typeof value === "string" && value.trim()) return value.trim();
    if (typeof value === "number") return String(value);
  }
  return null;
}

export function toBoolean(value: unknown): boolean | null {
  if (typeof value === "boolean") return value;
  if (typeof value === "string") {
    const v = value.toLowerCase().trim();
    if (v === "true" || v === "1" || v === "yes") return true;
    if (v === "false" || v === "0" || v === "no") return false;
  }
  return null;
}

export function formatDate(value: string | null | undefined, locale = "sk-SK"): string | null {
  if (!value) return null;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat(locale, { day: "2-digit", month: "2-digit", year: "numeric" }).format(date);
}

export function maxSeverity(values: Severity[]): Severity {
  const order: Record<Severity, number> = { neutral: 0, info: 1, warning: 2, critical: 3 };
  return values.reduce((max, current) => (order[current] > order[max] ? current : max), "neutral" as Severity);
}

export function compactText(parts: Array<string | null | undefined>, separator = "\n\n"): string | null {
  const cleaned = parts.map(p => p?.trim()).filter(Boolean) as string[];
  return cleaned.length ? cleaned.join(separator) : null;
}

export function safeArray<T>(value: T | T[] | null | undefined): T[] {
  if (Array.isArray(value)) return value;
  if (value === null || value === undefined) return [];
  return [value];
}
