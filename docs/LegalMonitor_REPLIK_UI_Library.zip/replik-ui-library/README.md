# LegalMonitor REPLIK UI Library

Purpose: give the developer a ready-to-implement presentation and normalization layer for Slovak IS REPLIK public API results, so the frontend shows clear labels such as **Konkurz**, **Oznam súdu**, **Iné zverejnenie**, not raw values such as `KONKURZ`, `OZNAM_SUD`, `INE_ZVEREJNENIE`.

This package is intentionally small. It does **not** try to replace the SOAP client. It provides:

1. SOAP envelope builders for the REPLIK public operations used by LegalMonitor.
2. Normalizers from parsed SOAP/XML objects to stable LegalMonitor objects.
3. SK/EN labels, explanations, severity levels and fallback handling for unknown REPLIK codes.
4. Frontend-ready card models for proceedings and public notices.
5. Example usage and expected output.

Source references used when preparing this library:

- Official REPLIK public API manual v1.0.10, dated 13.04.2026.
- Official production WSDLs:
  - `https://replik-ws.justice.sk/ru-verejnost-ws/konanieService.wsdl`
  - `https://replik-ws.justice.sk/ru-verejnost-ws/oznamService.wsdl`
- Official test WSDLs:
  - `https://replik-wst.justice.sk/ru-verejnost-ws/konanieService.wsdl`
  - `https://replik-wst.justice.sk/ru-verejnost-ws/oznamService.wsdl`
- Official example-call files:
  - `https://www.justice.gov.sk/dokumenty/2025/09/examples-konania.txt`
  - `https://www.justice.gov.sk/dokumenty/2025/09/examples-verejneOznamy.txt`

## Important REPLIK facts for implementation

- REPLIK public API is SOAP/XML, not REST/JSON.
- Production API is publicly available without registration according to the official manual.
- Test environment requires registration and IP information according to the official manual.
- Inputs and outputs are XML.
- Time is documented as ISO 8601 UTC.
- List pagination starts at page `0`.
- `VysledkovNaStranku` maximum is `100`.
- The manual documents `KonanieTyp` and `OznamTyp` values, but does not provide a separate code-list API for user-facing labels. Therefore LegalMonitor should map codes locally.

## Recommended app flow

### Search regime 1: IČO

Use when the user enters IČO.

1. `getKonaniePodlaICO`
2. `getVerejneOznamyPodlaICO`
3. For each important proceeding: `getKonanieDetail`
4. For each important notice: `getVerejnyOznamDetail`
5. Normalize and render via this library.

### Search regime 2: Full text

Use when the user enters name, surname, company name or ambiguous search text.

1. `vyhladajKonanie`
2. For each proceeding: `getKonanieDetail`
3. For each proceeding with case number and court code: `getVerejnyOznamPodlaZnackyASudu`
4. For each important notice: `getVerejnyOznamDetail`
5. Normalize and render via this library.

### Search regime 3: Period search

Use for monitoring/admin screen and periodic checks.

1. `getKonaniePreObdobie`
2. `getVerejneOznamyPreObdobie`
3. Detail calls only if the user opens a record or if the summary requires full text.
4. Normalize and render via this library.

## Installation into the app

Copy the `src` folder into the LegalMonitor project, for example:

```text
server/lib/replik-ui/
```

Or keep it as a local package and import from it.

Install XML parser dependency if using `src/xml.ts`:

```bash
npm install fast-xml-parser
```

If your app already uses a SOAP library such as `soap`, you can ignore `src/xml.ts` and pass the parsed object to the normalizers.

## Main files

| File | Purpose |
|---|---|
| `src/types.ts` | Stable TypeScript types for normalized records and frontend cards. |
| `src/labels.ts` | SK/EN code mapping, explanations, severity and fallback labels. |
| `src/normalizers.ts` | Converts parsed REPLIK objects into stable LegalMonitor records. |
| `src/presenters.ts` | Converts normalized records into frontend-ready card models. |
| `src/soap.ts` | SOAP envelope builders and endpoint constants. |
| `src/xml.ts` | Optional `fast-xml-parser` helpers. |
| `i18n/*.json` | JSON label dictionaries for apps that prefer config-driven translations. |
| `examples/usage.ts` | End-to-end example. |

## Code mapping policy

Always store both:

```json
{
  "rawCode": "INE_ZVEREJNENIE",
  "displayLabel": "Iné zverejnenie",
  "description": "Všeobecný typ zverejnenia bez špecifickejšieho verejne dokumentovaného zaradenia."
}
```

Never discard the raw REPLIK value. Unknown future codes must still be rendered safely.

Unknown code fallback:

```text
NEW_UNKNOWN_CODE -> New Unknown Code
```

The UI should also expose the raw code in record detail or developer/debug section.

## Confirmed / documented code groups

### `konanieTyp`

The official manual documents these proceeding type values:

| Raw REPLIK code | Canonical internal key | SK label | EN label |
|---|---|---|---|
| `KONKURZ` | `KONKURZ` | Konkurz | Bankruptcy |
| `MALYKONKURZ` | `MALYKONKURZ` | Malý konkurz | Small bankruptcy |
| `RESTRUKTURALIZACIA` | `RESTRUKTURALIZACIA` | Reštrukturalizácia | Restructuring |
| `INEKONANIA` | `INEKONANIA` | Iné konanie | Other proceeding |
| `ODDLZENIE-KONKURZ` / `ODDLZENIE_KONKURZ` | `ODDLZENIE_KONKURZ` | Oddlženie – konkurz | Debt relief – bankruptcy |
| `ODDLZENIE-SPLATKOVYKALENDAR` / `ODDLZENIE_SPLATKOVY_KALENDAR` | `ODDLZENIE_SPLATKOVY_KALENDAR` | Oddlženie – splátkový kalendár | Debt relief – repayment schedule |
| `LIKVIDACIA` | `LIKVIDACIA` | Likvidácia | Liquidation |
| `VPR` | `VPR` | Verejná preventívna reštrukturalizácia | Public preventive restructuring |

### `oznamTyp`

| Raw REPLIK code | SK label | EN label |
|---|---|---|
| `OZNAM_SUD` | Oznam súdu | Court notice |
| `OZNAM_SPRAVCA` | Oznam správcu | Administrator notice |

### `druhPodania`

The public manual confirms the field exists and gives `INE_ZVEREJNENIE` as an example. It does not publish a complete public code list for this field. Start with this value and keep fallback handling active.

| Raw REPLIK code | SK label | EN label |
|---|---|---|
| `INE_ZVEREJNENIE` | Iné zverejnenie | Other publication |

## Frontend rendering model

The frontend should consume `DisplayCard` objects rather than raw REPLIK data.

Example proceeding card:

```json
{
  "id": "8647",
  "type": "proceeding",
  "title": "Konkurz",
  "subtitle": "eMTrade a.s. · IČO 36628760\nOkresný súd Banská Bystrica · 2K/98/2016",
  "date": "09.03.2017",
  "severity": "critical",
  "badges": [
    {
      "label": "Konkurz",
      "tone": "critical",
      "rawCode": "KONKURZ",
      "tooltip": "Insolvenčné konanie týkajúce sa majetku dlžníka."
    }
  ],
  "fields": [
    { "key": "debtor", "label": "Dlžník", "value": "eMTrade a.s.", "important": true },
    { "key": "debtorIco", "label": "IČO dlžníka", "value": "36628760", "important": true },
    { "key": "caseNumber", "label": "Spisová značka", "value": "2K/98/2016", "important": true }
  ]
}
```

## UI design recommendation

Render the result screen in this order:

1. Summary bar.
2. Critical/warning proceedings first.
3. Public-notice timeline sorted by publication date descending.
4. Detail drawer/modal with all fields.
5. Raw source section, collapsed by default.

Recommended badge colors:

| Severity | Meaning |
|---|---|
| `critical` | bankruptcy / small bankruptcy |
| `warning` | restructuring, liquidation, public preventive restructuring, debt relief |
| `info` | notice metadata / unknown code |
| `neutral` | stopped or completed status |

## Example usage

```ts
import {
  buildGetKonaniePodlaIcoRequest,
  normalizeProceedingListItem,
  proceedingToCard
} from "./replik-ui";

const xml = buildGetKonaniePodlaIcoRequest({ ico: "36628760", page: 0, pageSize: 100 });

// Send xml to REPLIK, parse response, then:
const normalized = normalizeProceedingListItem(rawKonanieInfo);
const card = proceedingToCard(normalized, "sk");
```

## Backend integration notes

Recommended cache key:

```text
replik:{searchMode}:{normalizedQuery}:{dateFrom}:{dateTo}:{page}:{pageSize}
```

Recommended cache duration:

```text
24 hours for user-triggered screening results
1-6 hours for period monitoring dashboards
```

Recommended safety:

- Timeout: 20-30 seconds.
- Retry: 2 attempts with exponential backoff.
- Concurrency: 1-2 concurrent calls per app instance.
- Store raw XML and normalized JSON for audit/debugging.
- Do not fail the whole LegalMonitor screening if REPLIK is temporarily unavailable; return connector status `error` and show a clear partial-result warning.

## What developer must still implement

1. Actual HTTP/SOAP client call.
2. Mapping from their chosen SOAP/XML parser response structure to the normalizer input.
3. Storage of raw XML and normalized JSON.
4. Frontend components that render `DisplayCard` and `SearchSummary`.
5. Monitoring for new/unknown raw codes so the label dictionaries can be extended over time.
