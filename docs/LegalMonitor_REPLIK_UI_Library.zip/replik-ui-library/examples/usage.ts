import {
  buildGetKonaniePodlaIcoRequest,
  buildGetVerejneOznamyPodlaIcoRequest,
  normalizeNoticeListItem,
  normalizeProceedingListItem,
  noticeToCard,
  proceedingToCard,
  buildSearchSummary
} from "../src";

// 1) Build SOAP requests. Send them to REPLIK serviceBase with HTTP POST and Content-Type: text/xml.
const konaniaXml = buildGetKonaniePodlaIcoRequest({ ico: "36628760", page: 0, pageSize: 100 });
const oznamyXml = buildGetVerejneOznamyPodlaIcoRequest({ ico: "36628760", page: 0, pageSize: 100 });
console.log(konaniaXml, oznamyXml);

// 2) After parsing SOAP XML into JS objects, normalize each result item.
// The exact parsed shape depends on your SOAP/XML client. Map the response list item into normalize* functions.
const rawKonanieInfo = {
  Id: "8647",
  SpisovaZnackaSudu: "2K/98/2016",
  Typ: "KONKURZ",
  DatumZacatiaKonania: "2017-01-20",
  DatumZacatiaProcesu: "2017-03-09",
  Dlznik: "eMTrade a.s.",
  DlznikIco: "36628760",
  Sud: "139",
  SudNazov: "Okresný súd Banská Bystrica",
  Spravca: "Insolvency Management Group k.s.",
  StavKonania: "SKONCENY_PROCES"
};

const rawOznamInfo = {
  OznamId: "240197",
  OznamTyp: "OZNAM_SUD",
  SudKod: "139",
  SudNazov: "Okresný súd Banská Bystrica",
  SpisovaZnackaSudnehoSpisu: "2K/98/2016",
  KonanieId: "8647",
  KonanieTyp: "KONKURZ",
  DatumVydania: "2017-01-19"
};

const proceeding = normalizeProceedingListItem(rawKonanieInfo);
const notice = normalizeNoticeListItem(rawOznamInfo);

// 3) Convert to frontend-ready cards.
const proceedingCard = proceedingToCard(proceeding, "sk");
const noticeCard = noticeToCard(notice, "sk");
const summary = buildSearchSummary({
  searchMode: "ico",
  query: { ico: "36628760" },
  proceedings: [proceeding],
  notices: [notice],
  locale: "sk"
});

console.log(JSON.stringify({ summary, proceedingCard, noticeCard }, null, 2));
